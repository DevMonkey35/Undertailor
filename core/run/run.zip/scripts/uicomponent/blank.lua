local _component;

function create(component)
	_component = component;
end
