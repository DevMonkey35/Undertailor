local _object;

function create(object)
	_object = object;
end